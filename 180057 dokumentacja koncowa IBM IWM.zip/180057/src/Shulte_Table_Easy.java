import java.awt.GridLayout;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.EventQueue;
import java.io.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Klasa, ktora jest odpowiedzialna za realizacje
 * pierwszego zadania w calej grze.
 */

public class Shulte_Table_Easy implements MouseListener {
    JFrame ramka_shulte_easy = new JFrame();
    JLabel[] okno;
    JLabel powrot_do_menu = new JLabel("Powrot do menu");
    JPanel obszar_gry = new JPanel();

    int kolejna_liczba;

    /**
     * Metoda, ktora sortuje tablice liczb
     * @param array - pomieszana tablica liczb
     */
    public static void shuffle(int[] array)
    {
        Random random = new Random();
        for(int i = 0; i < array.length; i++)
        {
            int losowy_index = random.nextInt(array.length);
            int losowa_cyfra_z_tablicy = array[losowy_index];
            array[losowy_index] = array[i];
            array[i] = losowa_cyfra_z_tablicy;
        }
    }

    /**
     * Konstruktor.
     * Do pliku zapisywany jest czas rozpoczecia zadania,
     * ktory bedzie uzywany do obliczenia calkowitego wyniku,
     * uzyskanego przez gracza, po wszystkich 3 zadaniach.
     *
     * Tworzone jest nowe okno, na ktorym wyswietlane sa pomieszane liczby,
     * ulozone w GridLayout.
     * @see GridLayout
     */
    public Shulte_Table_Easy(){

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyy HH:mm:ss");
        LocalDateTime ldt = LocalDateTime.now();
        String czas_poczatkowy = dtf.format(ldt);


        try {
            BufferedReader reader = new BufferedReader(new FileReader("res/scores.txt"));
            String line = reader.readLine();
            List<String> temp_array = new ArrayList<>();

            while (line != null)
            {
                temp_array.add(line);
                line = reader.readLine();

            }
            String[] tempsArray = temp_array.toArray(new String[0]);

            try {
                FileWriter myWriter = new FileWriter("res/scores.txt", false);
                tempsArray[0] = czas_poczatkowy;
                for (int i = 0; i < tempsArray.length; i++) {
                    myWriter.write(tempsArray[i] + "\n");
                }
                myWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        kolejna_liczba = 1;

        ramka_shulte_easy.setTitle("Twoim zadaniem jest znaleźć liczbę 1.");
        ramka_shulte_easy.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ramka_shulte_easy.setSize(650,700);
        ramka_shulte_easy.setResizable(false);
        ramka_shulte_easy.setLayout(null);
        ramka_shulte_easy.setLocationRelativeTo(null);
        ramka_shulte_easy.getContentPane().setBackground(new Color(107, 184, 202));

        obszar_gry.setLayout(new GridLayout(3,3));
        obszar_gry.setSize(650,600);
        obszar_gry.setVisible(true);

        ramka_shulte_easy.add(obszar_gry);

        powrot_do_menu.setBounds(15,620,170,30);
        powrot_do_menu.setBorder(BorderFactory.createLineBorder(Color.black));
        powrot_do_menu.addMouseListener(this);
        powrot_do_menu.setOpaque(true);
        powrot_do_menu.setBackground(Color.WHITE);
        powrot_do_menu.setFont(new Font("DejaVu Sans Mono", Font.PLAIN, 20));
        powrot_do_menu.setHorizontalAlignment(SwingConstants.CENTER);
        ramka_shulte_easy.add(powrot_do_menu);

        okno = new JLabel[9];
        int[] liczby_easy = {1,2,3,4,5,6,7,8,9};
        shuffle(liczby_easy);

        for (int i = 0;i<9;i++){

            okno[i]=new JLabel(""+liczby_easy[i]); //wypełnia środki kwadratów kolejnymi liczbami z pomieszanej tablicy
            okno[i].setOpaque(true);
            okno[i].setBackground(Color.WHITE);
            okno[i].setHorizontalAlignment(SwingConstants.CENTER);
            okno[i].setFont(new Font("DejaVu Sans Mono", Font.PLAIN, 40)); //większa czcionka, żeby było lepiej widać
            okno[i].setBorder(BorderFactory.createLineBorder(Color.black));
            okno[i].addMouseListener(this); // ten sam Listener do każdego kwadratu
        }

        for (JLabel jLabel : okno) obszar_gry.add(jLabel); // dodaje wszystkie kwadraty
        ramka_shulte_easy.setVisible(true);
    }

    /**
     * Metoda obslugujaca wcisnięcie i odpuszczenie LPM.
     * Kiedy to nastepuje, program sprawdza, jaka liczba
     * zostala nacisnieta. Jezeli jest to ta,
     * ktorej obecnie szuka gracz, program zwieksza
     * szukana liczbę o 1. Po wcisnięciu ostatniej szukanej liczby,
     * uruchomione zostaje kolejne zadanie
     *
     * @param e obiekt MouseEvent odpowiedzialny za obslugę wcisniecia
     *         i odpuszczenia LPM
     * @see MouseEvent
     */
    @Override
    public void mouseClicked(MouseEvent e) { //naciśnięcie myszki

        JLabel nacisniete = (JLabel) e.getSource();

        if (String.valueOf(nacisniete.getText()).equals( String.valueOf(kolejna_liczba))) {
            ramka_shulte_easy.setTitle("Ostatnia liczba, która została znaleziona to: " + kolejna_liczba);
            kolejna_liczba++;
            System.out.println("Teraz musisz nacisnąć: " + kolejna_liczba);

        }
        if(kolejna_liczba == 10) {

            Zapamietywanie_Numerow_Easy zne = new Zapamietywanie_Numerow_Easy();
            zne.ramka.setVisible(true);
            ramka_shulte_easy.dispose();
        }
    }
    /**
     * Metoda obslugujaca wcisniecie LPM.
     * Kiedy to nastepuje, program sprawdza, jaka liczba
     * zostala nacisnieta. Jezeli jest to ta,
     * ktorej obecnie szuka gracz, zostaje ona podswietlona na zielono.
     * W przeciwnym wypadku, zostaje podswietlona na czerwono
     *
     * Jezeli gracz wybral opcje powrotu do menu, gra zostaje zakonczona
     * i uruchomione zostaje menu graficzne
     *
     * @param e obiekt MouseEvent odpowiedzialny za obsluge wcisniecia LPM
     * @see MouseEvent
     */
    public void mousePressed(MouseEvent e) {
        JLabel wcisniete = (JLabel) e.getSource();
        if (String.valueOf(wcisniete.getText()).equals( String.valueOf(kolejna_liczba))) {
            wcisniete.setBackground(Color.GREEN);
        }
        if (!String.valueOf(wcisniete.getText()).equals( String.valueOf(kolejna_liczba))) {
            wcisniete.setBackground(Color.RED);
        }
        if (String.valueOf(wcisniete.getText()).equals("Powrot do menu"))
        {
            EventQueue.invokeLater(new Runnable() {
                @Override
                public void run() {new Menu();}

            });
            ramka_shulte_easy.dispose();
        }
    }
    /**
     * Metoda obslugujaca przemieszczanie się kursora.
     * W przypadku kiedy kursor wjechal na konkretne pole,
     * zmieniany jest kolor tla tego pola na szary
     * @param e obiekt MouseEvent odpowiedzialny za obsluge przemieszczania kursora
     * @see MouseEvent
     */
    public void mouseEntered(MouseEvent e) // zmienia kolor na szary, żeby można było zobaczyć, na którym polu jest kursor
    {
        JLabel kursor_wjechal = (JLabel) e.getSource();
        if (String.valueOf(kursor_wjechal.getText()).equals("Powrot do menu"))
            kursor_wjechal.setBackground(Color.RED);
        else
            kursor_wjechal.setBackground(Color.LIGHT_GRAY);

    }
    /**
     * Metoda obslugujaca przemieszczanie sie kursora.
     * W przypadku kiedy kursor opuscil konkretne pole,
     * w ktorym się znajdowal, kolor tla pola zostaje zmieniony z
     * powrotem na domyslny, czyli bialy
     * @param e obiekt MouseEvent odpowiedzialny za obsluge przemieszczania kursora
     * @see MouseEvent
     */
    public void mouseExited(MouseEvent e)
    {
        JLabel kursor_oposcil = (JLabel) e.getSource();
        kursor_oposcil.setBackground(Color.WHITE);
    } // po wyjściu kursora z danego pola, zmienia z powrotem na białe
    /**
     * Metoda obslugujaca odpuszczenie LPM.
     * W momencie odpuszczenia LPM, kolor tla zmienia sie na szary,
     * tak, zeby bylo widac, gdzie znajduje sie kursor, po odpuszczeniu przycisku.
     * @param e obiekt MouseEvent odpowiedzialny za obsluge odpuszczenia LPM
     * @see MouseEvent
     */
    public void mouseReleased(MouseEvent e){
        JLabel przycisk_odpuszczony = (JLabel) e.getSource();
        przycisk_odpuszczony.setBackground(Color.LIGHT_GRAY);
    }

}
