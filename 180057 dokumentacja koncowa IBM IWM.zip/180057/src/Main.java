import java.awt.EventQueue;

/**Klasa Main
 * Gra, majaca za zadanie rozwoj pamieci krotkotrwalej
 * oraz widzenia peryferyjnego. Gra zostala stworzona
 * na potrzeby projektu ze Wspolczesnych Językow
 * Programowania w semestrze zimowym 2021/2022
 *
 * @author  Jakub Chilczuk
 */

public class Main {
    /**
     * metoda main, odpowiedzialna za uruchomienie menu
     * @param args Niewykorzystywane.
     * @see EventQueue
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(Menu::new);
    }
}